-- Raceboard (Client) - F4 Modern Style
-- Modes : Course / Essais Libres / Qualifications / Formation Lap

local M = {}

local raceName        = "Raceboard"
local logTag          = "Raceboard"
local lapCount        = nil
local formationActive = false
local lapOffset       = 0    -- 1 pendant formation (tours comptés pendant formation lap)

-- Session
local sessionMode      = "race"   -- "race" | "el" | "qualifs" | "qualifEnd"
local sessionRemaining = nil      -- secondes restantes (qualifs)
local sessionDuration  = nil      -- durée totale qualifs

M.dependencies = {"ui_imgui"}
local gui_module = require("ge/extensions/editor/api/gui")
local gui = {setupEditorGuiTheme = nop}
local im  = ui_imgui
local windowOpen = im.BoolPtr(true)
local ffi = require('ffi')

local players = {}

local function tableLength(t)
    local n = 0; for _ in pairs(t) do n = n + 1 end; return n
end

local function configRace(data)
    if data == "null" then return end
    data = jsonDecode(data)
    raceName = data['raceName'] or raceName
    lapCount = tonumber(data['lapCount']) or lapCount
end

local function prettyTime(s)
    local t  = s * 1000
    local mm = math.floor(t / 60000) % 60
    local ss = math.floor(t / 1000)  % 60
    local ms = math.floor(t % 1000)
    return string.format("%02d:%02d.%03d", mm, ss, ms)
end

local function prettyCountdown(s)
    if not s then return "--:--" end
    s = math.max(0, math.floor(s))
    local mm = math.floor(s / 60)
    local ss = s % 60
    return string.format("%02d:%02d", mm, ss)
end

local function prettyGap(s)
    if s == nil then return "--" end
    if s == 0   then return "LEADER" end
    return string.format("+%.3fs", s)
end

local function clientRaceboardData(data)
    if data == "null" then return end
    data = jsonDecode(data)
    if type(data) ~= "table" then return end
    players = {}
    for id, player in pairs(data) do
        if type(player) == "table" and player['name'] then
            local norm = { name = player['name'], splits = player['splits'], position = player['position'] }
            for k, v in pairs(player) do
                local n = tonumber(k)
                if n and type(v) == "table" then norm[n] = v end
            end
            players[tostring(id)] = norm
        end
    end
end

local function onFormation(data)
    if data == "null" then return end
    data = jsonDecode(data)
    if     data['trigger'] == 'formationStart' then
        formationActive = true
        lapOffset = 1   -- les tours du formation lap ne comptent pas dans la course
    elseif data['trigger'] == 'formationEnd' then
        formationActive = false
        -- lapOffset reste à 1 pour que le 1er tour de course = 1
    end
end

local function onSession(data)
    if data == "null" then return end
    data = jsonDecode(data)
    if data['trigger'] ~= 'sessionUpdate' then return end
    local prevMode = sessionMode
    sessionMode      = data['mode']      or "race"
    sessionRemaining = data['remaining']
    sessionDuration  = data['duration']  or sessionDuration
    -- Quand la course démarre, reset lapOffset
    if sessionMode == "race" and prevMode ~= "race" then
        lapOffset = 0
    end
end

-- ─── Couleurs ─────────────────────────────────────────────────────────────────
local gold   = im.ImVec4(1.00, 0.78, 0.00, 1.0)
local silver = im.ImVec4(0.78, 0.78, 0.82, 1.0)
local bronze = im.ImVec4(0.80, 0.46, 0.15, 1.0)
local white  = im.ImVec4(1.00, 1.00, 1.00, 1.0)
local dimcol = im.ImVec4(0.55, 0.55, 0.60, 1.0)
local green  = im.ImVec4(0.15, 0.90, 0.35, 1.0)
local red    = im.ImVec4(0.95, 0.22, 0.22, 1.0)
local accent = im.ImVec4(0.90, 0.15, 0.15, 1.0)
local cyan   = im.ImVec4(0.20, 0.85, 0.95, 1.0)
local orange = im.ImVec4(1.00, 0.55, 0.10, 1.0)
local sepcol = im.ImVec4(0.18, 0.18, 0.28, 1.0)
local yellow = im.ImVec4(1.00, 0.85, 0.00, 1.0)
local blue   = im.ImVec4(0.25, 0.55, 1.00, 1.0)
local purple = im.ImVec4(0.75, 0.30, 1.00, 1.0)
local btnred = im.ImVec4(0.55, 0.08, 0.08, 1.0)
local btnhov = im.ImVec4(0.75, 0.12, 0.12, 1.0)
local btnact = im.ImVec4(0.35, 0.04, 0.04, 1.0)

local function posColor(p)
    if p == 1 then return gold elseif p == 2 then return silver
    elseif p == 3 then return bronze else return white end
end

local function tc(col, txt)
    im.PushStyleColor2(im.Col_Text, col)
    im.Text(txt)
    im.PopStyleColor()
end

local function getBestTime(p)
    local best = nil
    for k,v in pairs(p) do
        if type(k)=="number" and type(v)=="table" and v['lapTime'] then
            if best==nil or v['lapTime']<best then best=v['lapTime'] end
        end
    end
    return best
end

local function getLastLap(p)
    local li, lt = nil, nil
    for k,v in pairs(p) do
        if type(k)=="number" and type(v)=="table" and v['lapTime'] then
            if li==nil or k>li then li=k; lt=v['lapTime'] end
        end
    end
    return lt
end

local function getCompletedLaps(p)
    local n=0
    for k,v in pairs(p) do
        if type(k)=="number" and type(v)=="table" and v['lapTime'] then n=n+1 end
    end
    return n
end

local function getPenalty(p)
    local n=0
    for k,v in pairs(p) do
        if type(k)=="number" and type(v)=="table" and v['penalty'] then n=n+v['penalty'] end
    end
    return n
end

-- ─── Overlay Formation Lap ────────────────────────────────────────────────────
local formOpen = im.BoolPtr(true)

local function drawFormationOverlay()
    local dw = im.GetIO().DisplaySize.x
    local dh = im.GetIO().DisplaySize.y
    local pw, ph = 480, 72

    im.SetNextWindowPos(im.ImVec2((dw-pw)*0.5, dh*0.07), im.Cond_Always)
    im.SetNextWindowSize(im.ImVec2(pw, ph), im.Cond_Always)
    im.SetNextWindowBgAlpha(0.93)

    local flags = im.WindowFlags_NoTitleBar + im.WindowFlags_NoResize
                + im.WindowFlags_NoScrollbar + im.WindowFlags_NoMove
                + im.WindowFlags_NoInputs + im.WindowFlags_NoBringToFrontOnFocus
                + im.WindowFlags_NoFocusOnAppearing + im.WindowFlags_NoSavedSettings

    im.PushStyleColor2(im.Col_WindowBg, im.ImVec4(0.06, 0.05, 0.00, 0.93))
    im.PushStyleColor2(im.Col_Border,   yellow)
    im.PushStyleVar1(im.StyleVar_WindowBorderSize, 3.0)
    im.PushStyleVar2(im.StyleVar_WindowPadding, im.ImVec2(14, 10))

    im.Begin("##RaceMPFormation", formOpen, flags)
    im.SetWindowFontScale(1.5)
    tc(yellow, "FORMATION LAP")
    im.SetWindowFontScale(1.0)
    tc(dimcol, "Maintenir la position — la course commence au /start")
    im.End()

    im.PopStyleVar(2)
    im.PopStyleColor(2)
end

-- ─── Overlay Session (EL / Qualifs) ──────────────────────────────────────────
local sessionOpen = im.BoolPtr(true)

local function drawSessionOverlay()
    local dw = im.GetIO().DisplaySize.x
    local dh = im.GetIO().DisplaySize.y
    local pw, ph = 480, 72

    im.SetNextWindowPos(im.ImVec2((dw-pw)*0.5, dh*0.07), im.Cond_Always)
    im.SetNextWindowSize(im.ImVec2(pw, ph), im.Cond_Always)
    im.SetNextWindowBgAlpha(0.93)

    local flags = im.WindowFlags_NoTitleBar + im.WindowFlags_NoResize
                + im.WindowFlags_NoScrollbar + im.WindowFlags_NoMove
                + im.WindowFlags_NoInputs + im.WindowFlags_NoBringToFrontOnFocus
                + im.WindowFlags_NoFocusOnAppearing + im.WindowFlags_NoSavedSettings

    local isEl      = sessionMode == "el"
    local isQualifs = sessionMode == "qualifs"
    local isEnd     = sessionMode == "qualifEnd"
    local borderCol = isEl and blue or (isEnd and green or purple)
    local bgCol     = isEl and im.ImVec4(0.00, 0.03, 0.10, 0.93)
                            or im.ImVec4(0.05, 0.00, 0.10, 0.93)

    im.PushStyleColor2(im.Col_WindowBg, bgCol)
    im.PushStyleColor2(im.Col_Border,   borderCol)
    im.PushStyleVar1(im.StyleVar_WindowBorderSize, 3.0)
    im.PushStyleVar2(im.StyleVar_WindowPadding, im.ImVec2(14, 10))

    im.Begin("##RaceMPSession", sessionOpen, flags)

    if isEl then
        im.SetWindowFontScale(1.5)
        tc(blue, "ESSAIS LIBRES")
        im.SetWindowFontScale(1.0)
        tc(dimcol, "Chrono libre — pas de limite de tours")

    elseif isQualifs then
        im.SetWindowFontScale(1.5)
        tc(purple, "QUALIFICATIONS")
        im.SetWindowFontScale(1.0)
        -- Timer + barre de progression
        local timeStr = prettyCountdown(sessionRemaining)
        -- Couleur du timer : rouge si < 2 min
        local timerCol = (sessionRemaining and sessionRemaining < 120) and red or white
        tc(timerCol, string.format("Temps restant : %s", timeStr))

    elseif isEnd then
        im.SetWindowFontScale(1.5)
        tc(green, "QUALIFICATIONS TERMINEES")
        im.SetWindowFontScale(1.0)
        tc(dimcol, "Classement final — /start pour lancer la course")
    end

    im.End()
    im.PopStyleVar(2)
    im.PopStyleColor(2)
end

-- ─── Leaderboard ──────────────────────────────────────────────────────────────
local function drawRaceboard()
    gui.setupWindow(raceName)

    local isEl      = sessionMode == "el"
    local isQualifs = sessionMode == "qualifs" or sessionMode == "qualifEnd"
    local borderCol = formationActive and yellow
                   or isEl            and blue
                   or isQualifs       and purple
                   or accent

    -- Label mode dans le titre
    local modeLabel
    if formationActive then      modeLabel = "FORMATION"
    elseif isEl then             modeLabel = "ESSAIS LIBRES"
    elseif sessionMode == "qualifs" then
        modeLabel = "QUALIFS  " .. prettyCountdown(sessionRemaining)
    elseif sessionMode == "qualifEnd" then modeLabel = "QUALIFS FIN"
    else                         modeLabel = "* LIVE" end

    local modeLabelCol = formationActive and yellow
                      or isEl            and blue
                      or isQualifs       and purple
                      or green

    im.PushStyleColor2(im.Col_WindowBg,      im.ImVec4(0.05, 0.05, 0.09, 0.97))
    im.PushStyleColor2(im.Col_TitleBg,       im.ImVec4(0.08, 0.08, 0.13, 1.00))
    im.PushStyleColor2(im.Col_TitleBgActive, im.ImVec4(0.10, 0.04, 0.04, 1.00))
    im.PushStyleColor2(im.Col_Border,        borderCol)
    im.PushStyleVar1(im.StyleVar_WindowBorderSize, 2.0)

    im.Begin(raceName)

    tc(accent, "[ F4 LEADERBOARD ]")
    im.SameLine()
    tc(modeLabelCol, modeLabel)
    im.SameLine()

    im.PushStyleColor2(im.Col_Button,        btnred)
    im.PushStyleColor2(im.Col_ButtonHovered, btnhov)
    im.PushStyleColor2(im.Col_ButtonActive,  btnact)
    im.PushStyleColor2(im.Col_Text,          white)
    if im.SmallButton(" RESET ") then players = {} end
    im.PopStyleColor(4)

    if lapCount and not isEl and not isQualifs then
        im.SameLine(); tc(dimcol, string.format("  [%d tours]", lapCount))
    end

    im.PushStyleColor2(im.Col_Separator, borderCol)
    im.Separator()
    im.PopStyleColor()

    -- En-têtes colonnes (pas de TOURS en EL/Qualifs)
    if isEl or isQualifs then
        tc(dimcol, " POS  PILOTE            TOURS    BEST LAP      LAST LAP      GAP")
    else
        tc(dimcol, " POS  PILOTE            TOURS    BEST LAP      LAST LAP      GAP           PEN")
    end
    im.PushStyleColor2(im.Col_Separator, sepcol)
    im.Separator()
    im.PopStyleColor()

    -- Tri : en EL/Qualifs par best lap; en course par position
    local sorted = {}
    for _, player in pairs(players) do table.insert(sorted, player) end

    if isEl or isQualifs then
        -- Tri par best lap (nil = en bas)
        table.sort(sorted, function(a, b)
            local ba = getBestTime(a)
            local bb = getBestTime(b)
            if ba and bb then return ba < bb end
            if ba then return true end
            return false
        end)
    else
        table.sort(sorted, function(a, b)
            local pa, pb = tonumber(a['position']), tonumber(b['position'])
            if pa and pb then return pa < pb end
            if pa then return true end
            return false
        end)
    end

    local leaderBest = sorted[1] and getBestTime(sorted[1]) or nil

    if tableLength(players) == 0 then tc(dimcol, "  En attente des joueurs...") end

    for i, player in ipairs(sorted) do
        local pos  = (isEl or isQualifs) and i or tonumber(player['position'])
        local name = player['name'] or "?"
        local pc   = posColor(i)   -- toujours basé sur le rang affiché
        local best = getBestTime(player)
        local last = getLastLap(player)
        local laps = getCompletedLaps(player)
        local pen  = getPenalty(player)
        local gap  = (i == 1) and 0 or (best and leaderBest and best - leaderBest or nil)

        -- Tours : soustraire lapOffset pour que la course commence à 1
        local displayLaps = math.max(0, laps - lapOffset)
        local lapStr = lapCount and not isEl and not isQualifs
                       and string.format("%d/%d", displayLaps, lapCount)
                       or string.format("%d", displayLaps)
        local lapCol = (lapCount and displayLaps >= lapCount and not isEl and not isQualifs) and green or cyan

        -- Position
        tc(pc, string.format(" P%-2d", i))
        im.SameLine()

        tc(i == 1 and gold or white, string.format(" %-14s", name:sub(1,14)))
        im.SameLine()
        tc(lapCol, string.format("  %-7s", lapStr))
        im.SameLine()
        tc(i == 1 and green or dimcol, string.format("  %s", best and prettyTime(best) or "--:--.---"))
        im.SameLine()

        local lastCol = white
        if last and best and last == best then lastCol = cyan end
        tc(lastCol, string.format("  %s", last and prettyTime(last) or "--:--.---"))
        im.SameLine()

        if i == 1 then
            tc(green,  string.format("  %-12s", "LEADER"))
        elseif gap then
            tc(orange, string.format("  %-12s", prettyGap(gap)))
        else
            tc(dimcol, string.format("  %-12s", "--"))
        end

        -- Pénalité seulement en course
        if not isEl and not isQualifs then
            im.SameLine()
            if pen > 0 then tc(red, string.format(" +%ds", pen))
            else tc(dimcol, "  -") end
        end

        im.PushStyleColor2(im.Col_Separator, sepcol)
        im.Separator()
        im.PopStyleColor()
    end

    im.PushStyleColor2(im.Col_Separator, borderCol)
    im.Separator()
    im.PopStyleColor()
    tc(accent, "RACEMP")
    im.SameLine()
    tc(dimcol, "| BeamMP Multiplayer Racing")

    im.PopStyleVar(1)
    im.PopStyleColor(4)
end

-- ─── Lifecycle ────────────────────────────────────────────────────────────────
local function onUpdate(dt)
    if worldReadyState == 2 then
        if formationActive then
            drawFormationOverlay()
        elseif sessionMode == "el" or sessionMode == "qualifs" or sessionMode == "qualifEnd" then
            drawSessionOverlay()
        end
        if windowOpen[0] == true then
            drawRaceboard()
        end
    end
end

local function onWorldReadyState() end

local function onExtensionLoaded()
    gui_module.initialize(gui)
    gui.registerWindow(raceName, im.ImVec2(700, 256))
    gui.showWindow(raceName)
    log('I', logTag, "Raceboard F4 Loaded")
end

local function onExtensionUnloaded()
    log('I', logTag, "Raceboard Unloaded")
end

AddEventHandler("clientRaceboardData", clientRaceboardData)
AddEventHandler("ConfigRace",          configRace)
AddEventHandler("RaceMPFormation",     onFormation)
AddEventHandler("RaceMPSession",       onSession)

M.onUpdate            = onUpdate
M.onWorldReadyState   = onWorldReadyState
M.onExtensionLoaded   = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded

return M
